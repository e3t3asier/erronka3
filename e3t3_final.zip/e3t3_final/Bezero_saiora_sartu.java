import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Bezero_saiora_sartu {

	String url = "jdbc:oracle:thin:@//localhost:1521/xe";
	String user = "oier2";
	String pass = "oier2";

	static int clientId = 1;

	private JFrame saioa_hasi_Frame = new JFrame("saioa_hasi_Frame");
	private JLabel erabiltzaileaL = new JLabel("Erabiltzailea:");
	private JLabel pasahitzaL = new JLabel("Pasahitza:");
	private JTextField erabiltzaileaT = new JTextField();
	private JPasswordField pasahitzaT = new JPasswordField();
	private JButton saioa_hasi_botoia = new JButton("Saioa hasi.");
	private JPanel saioa_hasi_panela = new JPanel(new GridLayout(2, 2));

	Bezero_saiora_sartu() {
		saioa_hasi_botoia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try (Connection konexioa = DriverManager.getConnection(url, user, pass)) {
					String erabiltzailea = erabiltzaileaT.getText();
					String pasahitza = pasahitzaT.getText();
					String kontsulta = "SELECT COUNT(*) AS count FROM BEZERO WHERE IZENA = ? AND EMAILA = ?";
					try (PreparedStatement st = konexioa.prepareStatement(kontsulta)) {
						st.setString(1, erabiltzailea);
						st.setString(2, pasahitza);
						ResultSet rs = st.executeQuery();
						if (rs.next()) {
							int count = rs.getInt("count");
							if (count > 0) {
								Bezero_hasiera_menua a = new Bezero_hasiera_menua();
								saioa_hasi_Frame.dispose();

								// AAA
								if (count > 0) {
									String getIdQuery = "SELECT ID FROM BEZERO WHERE IZENA = ? AND EMAILA = ?";
									try (PreparedStatement getIdStatement = konexioa.prepareStatement(getIdQuery)) {
										getIdStatement.setString(1, erabiltzailea);
										getIdStatement.setString(2, pasahitza);
										ResultSet idResult = getIdStatement.executeQuery();
										if (idResult.next()) {
											clientId = idResult.getInt("ID");
										}
									}
									saioa_hasi_Frame.dispose();
								} else {
									Saio_hasieraren_errore_mezua aaa = new Saio_hasieraren_errore_mezua();
								}
							} else {
								Saio_hasieraren_errore_mezua aaa = new Saio_hasieraren_errore_mezua();
							}
						}
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		saioa_hasi_panela.add(erabiltzaileaL);
		saioa_hasi_panela.add(erabiltzaileaT);
		saioa_hasi_panela.add(pasahitzaL);
		saioa_hasi_panela.add(pasahitzaT);

		saioa_hasi_Frame.add(saioa_hasi_panela);
		saioa_hasi_Frame.add(saioa_hasi_botoia);
		JPanel b = new JPanel();
		b.add(saioa_hasi_botoia);

		saioa_hasi_Frame.add(saioa_hasi_panela, BorderLayout.CENTER);
		saioa_hasi_Frame.add(b, BorderLayout.SOUTH);

		saioa_hasi_Frame.pack();
		saioa_hasi_Frame.setVisible(true);
		saioa_hasi_Frame.setPreferredSize(new Dimension(500, 500));
		saioa_hasi_Frame.setLocationRelativeTo(null);

	}

	public static int getClientId() {
		return clientId;
	}
}
