import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Saltzaile_edo_bezero {
	
	private JFrame saltzaile_edo_bezero = new JFrame("A");
	private JButton saltzaile = new JButton("Saltzailea");
	private JButton bezero = new JButton("Bezeroa");
	private JLabel saltzaile_edo_bezero_label = new JLabel("Zer zara?");
	private JPanel saltzaile_edo_bezero_panela = new JPanel();
	private JPanel saltzaile_edo_bezero_botoiak = new JPanel();
	
	Saltzaile_edo_bezero() {
		saltzaile.addActionListener(new ActionListener() {
       	public void actionPerformed(ActionEvent e) {
       		Saltzaile_saiora_sartu a = new Saltzaile_saiora_sartu();
       		saltzaile_edo_bezero.dispose();
            }
       });
		
		bezero.addActionListener(new ActionListener() {
       	public void actionPerformed(ActionEvent e) {
       		Bezero_saiora_sartu aa = new Bezero_saiora_sartu();
       		saltzaile_edo_bezero.dispose();
            }
       });
		
		saltzaile_edo_bezero_botoiak.add(saltzaile);
		saltzaile_edo_bezero_botoiak.add(bezero);
		saltzaile_edo_bezero_panela.add(saltzaile_edo_bezero_label);
		saltzaile_edo_bezero_panela.add(saltzaile_edo_bezero_botoiak);
		saltzaile_edo_bezero.setPreferredSize(new Dimension(500, 500));
		saltzaile_edo_bezero.pack();
		saltzaile_edo_bezero.add(saltzaile_edo_bezero_panela);
		saltzaile_edo_bezero.setLocationRelativeTo(null);
		saltzaile_edo_bezero.setVisible(true);
	}
}
