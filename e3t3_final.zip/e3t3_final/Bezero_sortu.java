import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Bezero_sortu {
	
	private String b = Erabiltzaile_sortu.getMaxId();
	private String url = "jdbc:oracle:thin:@//localhost:1521/xe";
	private String user = "oier2";
	private String pass = "oier2";
	
	private JFrame bezero_sortu_Frame = new JFrame("bezero_sortu_Frame");
	private JLabel bezero_sortu_label_id = new JLabel("ID:");
	private JLabel bezero_sortu_label_izena = new JLabel("Izena:");
	private JLabel bezero_sortu_label_abizena = new JLabel("Abizena:");
	private JLabel bezero_sortu_label_helbidea = new JLabel("Helbidea:");
	private JLabel bezero_sortu_label_emaila = new JLabel("Emaila (pasahitza):");
	private JLabel bezero_sortu_text_id = new JLabel(b);

	private JTextField bezero_sortu_text_izena = new JTextField();
	private JTextField bezero_sortu_text_abizena = new JTextField();
	private JTextField bezero_sortu_text_helbidea = new JTextField();
	private JTextField bezero_sortu_text_emaila = new JTextField();
	private JButton bezero_sortu_botoia = new JButton("Bezero erabiltzailea sortu.");
	
	Bezero_sortu() {
		bezero_sortu_botoia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String[] informazioa = new String[5];
				informazioa[0] = b;
				informazioa[1] = bezero_sortu_text_izena.getText();
				informazioa[2] = bezero_sortu_text_abizena.getText();
				informazioa[3] = bezero_sortu_text_helbidea.getText();
				informazioa[4] = bezero_sortu_text_emaila.getText();

				JFrame bezero_mezua_Frame = new JFrame("bezero_mezua_Frame");
				JLabel bezero_mezua_Label = new JLabel("Este mensaje sale aunque so ne haya creado.");
				JButton bezero_mezua_Button = new JButton("Onartu.");
				bezero_mezua_Frame.add(bezero_mezua_Label, BorderLayout.NORTH);
				bezero_mezua_Frame.add(bezero_mezua_Button, BorderLayout.SOUTH);
				bezero_mezua_Button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						bezero_mezua_Frame.dispose();

					}
				});
				bezero_mezua_Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				bezero_mezua_Frame.pack();
				bezero_mezua_Frame.setPreferredSize(new Dimension(500, 500));
				bezero_mezua_Frame.setLocationRelativeTo(null);
				bezero_mezua_Frame.setVisible(true);
				bezero_sortu_Frame.dispose();

				
				String insertQuery = "INSERT INTO BEZERO (ID, IZENA, ABIZENA, HELBIDEA, EMAILA) VALUES (?, ?, ?, ?, ?)";
				try (Connection konexioa = DriverManager.getConnection(url, user, pass)) {
					PreparedStatement insertStatement = konexioa.prepareStatement(insertQuery);
					insertStatement.setString(1, informazioa[0]);
					insertStatement.setString(2, informazioa[1]);
					insertStatement.setString(3, informazioa[2]);
					insertStatement.setString(4, informazioa[3]);
					insertStatement.setString(5, informazioa[4]);
					int filasAfectadas = insertStatement.executeUpdate();
					if (filasAfectadas > 0) {
						Informazio_mezuak.mezu_ona("Informazioa ondo insertatu da.");
					} else {
						Informazio_mezuak.mezu_errorea("Ezin izan da informazioa sartu.");
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		JPanel bezero_sortu_label = new JPanel(new GridLayout(5, 2));
		bezero_sortu_label.add(bezero_sortu_label_id);
		bezero_sortu_label.add(bezero_sortu_text_id);
		bezero_sortu_label.add(bezero_sortu_label_izena);
		bezero_sortu_label.add(bezero_sortu_text_izena);
		bezero_sortu_label.add(bezero_sortu_label_abizena);
		bezero_sortu_label.add(bezero_sortu_text_abizena);
		bezero_sortu_label.add(bezero_sortu_label_helbidea);
		bezero_sortu_label.add(bezero_sortu_text_helbidea);
		bezero_sortu_label.add(bezero_sortu_label_emaila);
		bezero_sortu_label.add(bezero_sortu_text_emaila);
		bezero_sortu_Frame.add(bezero_sortu_label, BorderLayout.NORTH);
		bezero_sortu_Frame.add(bezero_sortu_botoia, BorderLayout.SOUTH);
		bezero_sortu_Frame.pack();
		bezero_sortu_Frame.setPreferredSize(new Dimension(500, 500));
		bezero_sortu_Frame.setLocationRelativeTo(null);
		bezero_sortu_Frame.setVisible(true);
		}
	}