import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Saioa_hasi_edo_kontua_sortu {
	private JFrame hasiera_Frame = new JFrame("hasiera_frame");
	private JButton saioa_hasi_botoia = new JButton("Saioa hasi.");
	private JButton erabiltzaile_sortu_botoia = new JButton("Erabiltzaile bat sortu.");
	private JLabel hasiera_Frame_mezua = new JLabel("Saioa hasi edo kontu bat sortu:");

	Saioa_hasi_edo_kontua_sortu() {
		saioa_hasi_botoia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Saltzaile_edo_bezero a = new Saltzaile_edo_bezero();
				hasiera_Frame.dispose();
			}
		});

		erabiltzaile_sortu_botoia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Erabiltzaile_sortu a = new Erabiltzaile_sortu();
				hasiera_Frame.dispose();
			}
		});

		JPanel hasiera_botoiak = new JPanel();
		hasiera_botoiak.add(saioa_hasi_botoia, BorderLayout.NORTH);
		hasiera_botoiak.add(erabiltzaile_sortu_botoia, BorderLayout.NORTH);

		hasiera_Frame.add(hasiera_Frame_mezua, BorderLayout.NORTH);
		hasiera_Frame.add(hasiera_botoiak, BorderLayout.SOUTH);

		hasiera_Frame.pack();
		hasiera_Frame.setPreferredSize(new Dimension(500, 500));
		hasiera_Frame.setLocationRelativeTo(null);
		hasiera_Frame.setVisible(true);
	}
}
