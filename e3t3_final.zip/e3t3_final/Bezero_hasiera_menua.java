import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Bezero_hasiera_menua {
	private JFrame bezero_hasiera_mezua = new JFrame("bezero_hasiera_meua");
	private JButton bezero_hasiera_menua_datuak_aldatu = new JButton("Nire datuak aldatu.");
	private JButton bezero_hasiera_menua_produktuak_bilatu = new JButton("Produktuak bilatu.");
	private JButton bezero_hasiera_menua_saioa_itxi = new JButton("Saioa itxi.");
	private JLabel bezero_hasiera_meua_testua = new JLabel("Zer egin nahi duzu?");
	private JPanel bezero_hasiera_meua_botoiak_Label = new JPanel(new GridLayout(3, 1));

	Bezero_hasiera_menua() {

		bezero_hasiera_menua_datuak_aldatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Bezero_datuak_aldatu a = new Bezero_datuak_aldatu();
				bezero_hasiera_mezua.dispose();
			}
		});

		bezero_hasiera_menua_produktuak_bilatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Bezero_produktuak_bilatu bb = new Bezero_produktuak_bilatu();
				bezero_hasiera_mezua.dispose();
			}
		});
		
		bezero_hasiera_menua_saioa_itxi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Saioa_hasi_edo_kontua_sortu a = new Saioa_hasi_edo_kontua_sortu();
				bezero_hasiera_mezua.dispose();
			}
		});

		bezero_hasiera_meua_botoiak_Label.add(bezero_hasiera_menua_datuak_aldatu);
		bezero_hasiera_meua_botoiak_Label.add(bezero_hasiera_menua_produktuak_bilatu);
		bezero_hasiera_meua_botoiak_Label.add(bezero_hasiera_menua_saioa_itxi);
		bezero_hasiera_mezua.add(bezero_hasiera_meua_botoiak_Label, BorderLayout.SOUTH);
		bezero_hasiera_mezua.add(bezero_hasiera_meua_testua, BorderLayout.NORTH);

		bezero_hasiera_mezua.pack();
		bezero_hasiera_mezua.setPreferredSize(new Dimension(500, 500));
		bezero_hasiera_mezua.setLocationRelativeTo(null);
		bezero_hasiera_mezua.setVisible(true);
	}
}
