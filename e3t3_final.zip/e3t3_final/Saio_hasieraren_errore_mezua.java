import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Saio_hasieraren_errore_mezua {

	Saio_hasieraren_errore_mezua() {
		JFrame errorea = new JFrame("A");
		JButton errorea_botoia = new JButton("Onartu.");
		JLabel errorea_label = new JLabel("Erabiltzailea edo pasahitza ez dira zuzenak. Saiatu berriz.");

		errorea_botoia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				errorea.dispose();
			}
		});
		errorea.add(errorea_label, BorderLayout.NORTH);
		errorea.add(errorea_botoia, BorderLayout.SOUTH);
		errorea.pack();
		errorea.setPreferredSize(new Dimension(500, 500));
		errorea.setLocationRelativeTo(null);
		errorea.setVisible(true);
	}
}
