import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Saltzailearen_produktu_kudeaketa {
	private JFrame produktu_bilatzailea_Frame = new JFrame("produktu_bilatzailea_Frame");
	private JButton produktu_gehitu = new JButton("Produktuak gehitu.");
	private JButton produktu_kendu = new JButton("Produktu kendu.");
	private JButton produktu_aldatu = new JButton("Produktuen informazioa aldatu.");
	private JPanel produktuak_bilatu_panela = new JPanel(new GridLayout(3, 1));
	
	Saltzailearen_produktu_kudeaketa() {
		
		produktu_gehitu.addActionListener(new ActionListener() {
       	public void actionPerformed(ActionEvent e) {
       		produktu_bilatzailea_Frame.dispose();
       		Saltzaile_produktuak_gehitu b = new Saltzaile_produktuak_gehitu();
            }
       });
		
		produktu_kendu.addActionListener(new ActionListener() {
       	public void actionPerformed(ActionEvent e) {
       		produktu_bilatzailea_Frame.dispose();
       		Saltzaile_produktuak_kendu a = new Saltzaile_produktuak_kendu();
            }
       });
		
		produktu_aldatu.addActionListener(new ActionListener() {
       	public void actionPerformed(ActionEvent e) {
       		produktu_bilatzailea_Frame.dispose();
       		Saltzaile_produktuak_aldatu c = new Saltzaile_produktuak_aldatu();
            }
       });
		
		produktuak_bilatu_panela.add(produktu_gehitu);
		produktuak_bilatu_panela.add(produktu_kendu);
		produktuak_bilatu_panela.add(produktu_aldatu);
		produktu_bilatzailea_Frame.add(produktuak_bilatu_panela);
		produktu_bilatzailea_Frame.pack();
		produktu_bilatzailea_Frame.setLocationRelativeTo(null);
		produktu_bilatzailea_Frame.setVisible(true);
	}
}