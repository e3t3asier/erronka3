import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
 
public class Saltzaile_produktuak_aldatu {
 
    private JFrame saltzaile_produktuak_modifikatu = new JFrame();
    private JButton saltzaile_produktuak_modifikatu_Button = new JButton("Modifikatu.");
    private JPanel saltzaile_produktuak_modifikatu_Panela = new JPanel(new GridLayout(7, 2));
 
    private JLabel saltzaile_produktuak_modifikatu_id = new JLabel("ID.");
    private JLabel saltzaile_produktuak_modifikatu_izena = new JLabel("Izena.");
    private JLabel saltzaile_produktuak_modifikatu_deskribapena = new JLabel("Deskribapena.");
    private JLabel saltzaile_produktuak_modifikatu_balioa = new JLabel("Balioa.");
    private JLabel saltzaile_produktuak_modifikatu_salneurria = new JLabel("Salneurria.");
    private JLabel saltzaile_produktuak_modifikatu_id_kategoria = new JLabel("ID kategoria (1-5).");
 
    private JTextField saltzaile_produktuak_modifikatu_idT = new JTextField();
    private JTextField saltzaile_produktuak_modifikatu_izenaT = new JTextField();
    private JTextField saltzaile_produktuak_modifikatu_deskribapenaT = new JTextField();
    private JTextField saltzaile_produktuak_modifikatu_balioaT = new JTextField();
    private JTextField saltzaile_produktuak_modifikatu_salneurriaT = new JTextField();
    private JTextField saltzaile_produktuak_modifikatu_id_kategoriaT = new JTextField();
 
    Saltzaile_produktuak_aldatu() {
        saltzaile_produktuak_modifikatu_Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = saltzaile_produktuak_modifikatu_idT.getText();
                String izena = saltzaile_produktuak_modifikatu_izenaT.getText();
                String deskribapena = saltzaile_produktuak_modifikatu_deskribapenaT.getText();
                String balioa = saltzaile_produktuak_modifikatu_balioaT.getText();
                String salneurria = saltzaile_produktuak_modifikatu_salneurriaT.getText();
                String id_kategoria = saltzaile_produktuak_modifikatu_id_kategoriaT.getText();
 
                modificarProducto(id, izena, deskribapena, balioa, salneurria, id_kategoria);
                saltzaile_produktuak_modifikatu.dispose();
            }
        });
 
        saltzaile_produktuak_modifikatu_Panela.add(saltzaile_produktuak_modifikatu_id);
        saltzaile_produktuak_modifikatu_Panela.add(saltzaile_produktuak_modifikatu_idT);
        saltzaile_produktuak_modifikatu_Panela.add(saltzaile_produktuak_modifikatu_izena);
        saltzaile_produktuak_modifikatu_Panela.add(saltzaile_produktuak_modifikatu_izenaT);
        saltzaile_produktuak_modifikatu_Panela.add(saltzaile_produktuak_modifikatu_deskribapena);
        saltzaile_produktuak_modifikatu_Panela.add(saltzaile_produktuak_modifikatu_deskribapenaT);
        saltzaile_produktuak_modifikatu_Panela.add(saltzaile_produktuak_modifikatu_balioa);
        saltzaile_produktuak_modifikatu_Panela.add(saltzaile_produktuak_modifikatu_balioaT);
        saltzaile_produktuak_modifikatu_Panela.add(saltzaile_produktuak_modifikatu_salneurria);
        saltzaile_produktuak_modifikatu_Panela.add(saltzaile_produktuak_modifikatu_salneurriaT);
        saltzaile_produktuak_modifikatu_Panela.add(saltzaile_produktuak_modifikatu_id_kategoria);
        saltzaile_produktuak_modifikatu_Panela.add(saltzaile_produktuak_modifikatu_id_kategoriaT);
        saltzaile_produktuak_modifikatu.add(saltzaile_produktuak_modifikatu_Panela, BorderLayout.NORTH);
        saltzaile_produktuak_modifikatu.add(saltzaile_produktuak_modifikatu_Button, BorderLayout.SOUTH);
 
        saltzaile_produktuak_modifikatu.pack();
        saltzaile_produktuak_modifikatu.setPreferredSize(new Dimension(500, 500));
        saltzaile_produktuak_modifikatu.setLocationRelativeTo(null);
        saltzaile_produktuak_modifikatu.setVisible(true);
    }

 
    private void modificarProducto(String id, String izena, String deskribapena, String balioa, String salneurria, String id_kategoria) {
        String url = "jdbc:oracle:thin:@localhost:1521:xe";
        String user = "oier2";
        String pass = "oier2";
        String updateQuery = "UPDATE produktu SET izena = ?, deskribapena = ?, balioa = ?, salneurria = ?, id_kategoria = ? WHERE id = ?";
 
        try (Connection connection = DriverManager.getConnection(url, user, pass);
             PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
            preparedStatement.setString(1, izena);
            preparedStatement.setString(2, deskribapena);
            preparedStatement.setString(3, balioa);
            preparedStatement.setString(4, salneurria);
            preparedStatement.setString(5, id_kategoria);
            preparedStatement.setString(6, id);
 
            int aldatutako_filak = preparedStatement.executeUpdate();
            if (aldatutako_filak > 0) {
                JOptionPane.showMessageDialog(saltzaile_produktuak_modifikatu, "Produktua ondo aldatu da.");
            } else {
                JOptionPane.showMessageDialog(saltzaile_produktuak_modifikatu, "Errorea produktua aldatzerakoan.");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}